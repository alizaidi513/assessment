from preswald import connect, get_df, query, text, table, slider, dropdown, plotly
import plotly.express as px

# 1. Load the dataset with verification
text("# 🏦 Finance Investment Dashboard")
connect()
df = get_df("Finance_data")

# Verify data loading
if df is None or df.empty:
    text("⚠️ Error: Could not load data. Please ensure:")
    text("- 'Finance_data.csv' exists in data/ folder")
    text("- File contains valid CSV data")
else:
    text(f"✅ Successfully loaded {len(df)} records")

# 2. Basic SQL query demonstration
text("## 📋 Sample Data (Age > 25)")
filtered_df = query("""
    SELECT gender, age, Avenue, Expect, Purpose, Duration 
    FROM Finance_data 
    WHERE age > 25 
    LIMIT 10
""", "Finance_data")
table(filtered_df)

# 3. Interactive controls
text("## 🔍 Filter Options")
age_threshold = slider("Minimum Age", 
                     min_val=int(df['age'].min()), 
                     max_val=int(df['age'].max()), 
                     default=30)

investment_type = dropdown("Investment Avenue",
                         options=['All'] + sorted(df['Avenue'].unique().tolist()),
                         default='All')

# 4. Dynamic filtering
sql_conditions = [f"age >= {age_threshold}"]
if investment_type != 'All':
    sql_conditions.append(f"Avenue = '{investment_type}'")

dynamic_data = query(f"""
    SELECT * FROM Finance_data
    WHERE {' AND '.join(sql_conditions)}
    ORDER BY age DESC
""", "Finance_data")

# 5. Enhanced Visualizations
text("## 📊 Investment Analytics")

# Visualization 1: Age Distribution
text("### Age Distribution of Investors")
fig1 = px.histogram(dynamic_data, x='age', nbins=10, 
                   title=f"Age Distribution (Filtered: {len(dynamic_data)} records)")
plotly(fig1)

# Visualization 2: Investment Preference
text("### Preferred Investment Avenues")
fig2 = px.pie(dynamic_data, names='Avenue', 
             title='Investment Type Distribution',
             hole=0.3)
plotly(fig2)

# Visualization 3: Expectation Analysis
text("### Return Expectations")
fig3 = px.box(dynamic_data, x='Avenue', y='Expect', color='gender',
             title="Expected Returns by Investment Type")
plotly(fig3)

# Visualization 4: Duration Analysis
text("### Investment Durations")
fig4 = px.bar(dynamic_data['Duration'].value_counts().reset_index(), 
             x='index', y='Duration',
             title="Popular Investment Durations",
             labels={'index':'Duration', 'Duration':'Count'})
plotly(fig4)

# 6. Show filtered results
text("## 🔎 Filtered Results")
table(dynamic_data.head(20))  # Show first 20 rows for better readability